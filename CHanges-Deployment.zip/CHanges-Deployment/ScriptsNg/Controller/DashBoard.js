﻿app.controller("DashBoardController", function ($scope, $http,$filter) {
    $scope.model = {};
    $scope.model.txtSearch = "";
    $scope.model.FromDate = moment().subtract(30, "days").format("DD-MM-YYYY");
    $scope.model.ToDate = moment().add(1, 'days').format("DD-MM-YYYY");
    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.StatusDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Status",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "DashBoard/GetStatus"
                }
            }
        },

        filter: "contains",
        suggest: true
    };

    $scope.OnStatusComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            SetComboValue("StatusId", null);
        }      
        $("#messageGrid").data("kendoGrid").dataSource.read();


    }


    $scope.GroupSearch = function () {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }

    $scope.checkData = function (e) {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }

    $scope.mainGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "DashBoard/GetAllItemsForDashBoard",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    opt.FromDate = $scope.model.FromDate;
                    opt.ToDate = $scope.model.ToDate;
                   
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {

                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,

        columns: [
             {
                 field: "ReferenceNumber",
                 title: "Ref. Number",
                 width: "80px",
                 filterable: false,

             },
               {
                   field: "VehicleType",
                   title: "Type",
                   width: "80px",
                   filterable: false,

               },
                {
                    field: "FirstName",
                    title: "First Name",
                    width: "80px",
                    filterable: false,

                },
                 {
                     field: "LastName",
                     title: "Last Name",
                     width: "80px",
                     filterable: false,

                 },
                  {
                      field: "Email",
                      title: "Email",
                      width: "80px",
                      filterable: false,

                  },
                   {
                       field: "Mobile",
                       title: "Mobile",
                       width: "80px",
                       filterable: false,

                   },
                   {
                       field: "CreatedBy",
                       title: "CreatedBy",
                       width: "80px",
                       filterable: false,

                   },

                {
                    field: "CreatedDate",
                    title: "Created Date",
                    width: "120px",
                    type: "date",
                    format: "{0:dd-MMM-yyyy}"

                },
                 {
                    field: "StatusName",
                    title: "Status",
                    width: "80px",
                    filterable: false,

                },
                


           {
               template: "<a href='javascript:void(0);' class='btn-edit'  ng-click='Edit(this)'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-delete' ng-click='deleteReg(this)'  data-toggle='tooltip' title='Delete'><i class='las la-trash-alt'></i></a>",
               width: "40px",
               title: "Action",
               headerAttributes: { style: "text-align:center;" },
               attributes: { style: "text-align:center;" },
           },

        ]
    };


    $scope.Registration = function (e) {
        window.location = "/Fastag/Registration";
    }
    $scope.Edit=function(e)
    {
        debugger;
        var Id=e.dataItem.Id;
        window.location = "/Fastag/Edit?Id=" + Id;
    }
   

  $scope.Search=function()
  {
      $("#mainGrid").data("kendoGrid").dataSource.read();
  }
   
  $scope.GetHeaderDetails = function () {

      $scope.ShowLoaderImg();
      $http({
          method: 'GET',
          url: baseUrl + 'DashBoard/GetDashBoardHeader'

      }).then(function (response) {
          $scope.ShowLoaderImg();
          var result = [];
          if (response.data) {
              for (var i = 0; i < response.data.length; i++) {
                  result.push({ TotalRegistration: response.data[i].TotalReg, TotalAmount: response.data[i].TotalAmount });
              }

          }
          $scope.list = result;
          // $scope.GetDashBoardDetails();
          $scope.HideLoaderImg();

      }, function errorCallback(response) {
          $scope.HideLoaderImg();
      });
  }


  $scope.deleteReg = function (e) {
      $scope.DeleteModel = {};
      var warnText = "Are you sure you want to delete this record?";
      $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
          if (confirmed) {
              $scope.ShowLoaderImg();
              $scope.DeleteModel.Id = e.dataItem.Id;
              $http({
                  method: 'POST',
                  url: baseUrl + 'Fastag/DeleteRegistration',
                  data: $scope.DeleteModel,
              }).then(function (response) {
                  debugger;
                  $scope.HideLoaderImg();
                  if (response.data == 'dependency') {
                      SetMessage('CantDelete')
                  }
                  else if (response.data == 'success') {
                      SetMessage('Delete')
                  }
                  else {
                      SetMessage('Error');
                  }
                  $("#mainGrid").data("kendoGrid").dataSource.read();


              }, function errorCallback(response) {
                  $scope.HideLoaderImg();
                  SetMessage('Error');

              });
          }
      });
  }



});