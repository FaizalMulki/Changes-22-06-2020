﻿var app = angular.module('app', ['kendo.directives', 'pascalprecht.translate', 'angular.filter']);
//kendo.culture("ar-AE");
if (localStorage.getItem("menubar") != null && localStorage.getItem("menubar") == "collapse") {
    $("body").removeClass('sidebar-collapse').trigger('expanded.pushMenu');
}

if (localStorage.getItem("liIndex") != null) {
    var index = localStorage.getItem("liIndex");
    $(".sidebar-menu > li:eq(" + index + ")").addClass("active");
}

$(document).on("click", ".sidebar-menu > li", function () {
    var index = $(this).index();
    localStorage.setItem("liIndex", index);
});

$.ajaxPrefilter(function (options) {
    if (options.url != "" && options.dataType != "script") {
        options.cache = false;
        //options.url = ApiUrl + options.url;
        options.url =options.url;
    }
});

$(document).ajaxError(function (e, xhr, settings) {
    if (xhr.status == 401) {
        {
            window.location = "/home/signout";
        }
    }
});

app.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);



app.directive('decimaltwoPlaced', function () {
    debugger
    return {
        link: function (scope, ele, attrs) {

            ele.bind('keypress', function (e) {
                debugger
                if (!isTextSelected($(this)[0])) {
                    var newVal = $(this).val() + (e.charCode !== 0 ? String.fromCharCode(e.charCode) : '');
                    if ($(this).val().search(/(.*)\.[0-9][0-9]/) === 0 && newVal.length > $(this).val().length) {
                        e.preventDefault();
                    }
                }
            });
        }
    };
});


function isTextSelected(input) {
    debugger
    var startPos = input.selectionStart;
    var endPos = input.selectionEnd;
    var doc = document.selection;

    if (doc && doc.createRange().text.length != 0) {
        return true;
    } else if (!doc && input.value.substring(startPos, endPos).length != 0) {
        return true;
    }
    return false;
}

app.directive('numbersOnly', function () {

    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});


app.directive('decimalsOnly', function () {
    return {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                var $input = $(this);
                var value = $input.val();
                value = value.replace(/[^0-9\.]/g, '')
                var findsDot = new RegExp(/\./g)
                var containsDot = value.match(findsDot)
                if (containsDot != null && ([46, 110, 190].indexOf(event.which) > -1)) {
                    event.preventDefault();
                    return false;
                }
                $input.val(value);
                if (event.which == 64 || event.which == 16) {
                    return false;
                } if ([8, 13, 27, 37, 38, 39, 40, 110].indexOf(event.which) > -1) {
                    return true;
                } else if (event.which >= 48 && event.which <= 57) {
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    return true;
                } else if ([46, 110, 190].indexOf(event.which) > -1) {
                    return true;
                }
                else if (event.which == 9) {
                    return true;
                }
                else {
                    event.preventDefault();
                    return false;
                }
            });
        }
    }
});


app.factory('uploadManager', function ($rootScope) {
    var _files = [];
    return {
        add: function (file) {
            _files.push(file);
            $rootScope.$broadcast('fileAdded', file.files[0].name);
        },
        clear: function () {
            _files = [];
        },
        files: function () {
            var fileNames = [];
            $.each(_files, function (index, file) {
                fileNames.push(file.files[0].name);
            });
            return fileNames;
        },
        upload: function () {
            $.each(_files, function (index, file) {
                file.submit();
            });
            this.clear();
        },
        setProgress: function (percentage) {
            $rootScope.$broadcast('uploadProgress', percentage);
        }
    };
});



app.directive('upload', ['uploadManager', function factory(uploadManager) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $(element).fileupload({
                dataType: 'text',
                add: function (e, data) {
                    uploadManager.add(data);
                },
                progressall: function (e, data) {
                    var progress = parseInt(data.loaded / data.total * 100, 10);
                    uploadManager.setProgress(progress);
                },
                done: function (e, data) {
                    uploadManager.setProgress(0);
                }
            });
        }
    };
}]);

app.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function (file, uploadUrl) {
        var fd = new FormData();
        fd.append('file', file);
        return $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: { 'Content-Type': undefined }
        });

    }
}]);

app.factory('BearerAuthInterceptor', ['$window', '$q', function ($window, $q) {
    return {
        request: function (config) {
            config.headers = config.headers || {};
            var ck = ReadCookie("tokenCookie");
            if (ck != null) {
                config.headers.Authorization = 'Bearer ' + ck;
            }
            return config || $q.when(config);
        },
        response: function (response) {
            if (response.status === 401) {
                window.location = "/home/signout";
            }
            return response || $q.when(response);
        }
    };
}]);

app.config(['$provide', function ($provide) {
    /**
      * Angular Material dynamically generates Style tags
      * based on themes and palletes; for each ng-app.
      * Let's disable generation and <style> DOM injections. 
      */
    $provide.constant('$MD_THEME_CSS', '/**/');
}]);

app.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.interceptors.push('BearerAuthInterceptor');
    var isIE = /*@cc_on!@*/false || !!document.documentMode;
    var isEdge = !isIE && !!window.StyleMedia;
    if (isIE || isEdge) {
        $httpProvider.interceptors.push('noCacheInterceptor');
    }
}]);

app.factory('noCacheInterceptor', function () {
    return {
        request: function (config) {
            if (config.method == 'GET') {
                var separator = config.url.indexOf('?') === -1 ? '?' : '&';
                config.url = config.url + separator + 'noCache=' + new Date().getTime();
            }
            return config;
        }
    };
});

$.ajaxSetup({
    beforeSend: function (xhr) {
        var ck = ReadCookie("tokenCookie");
        if (ck != null) {
            var header = "Bearer " + ck;
            xhr.setRequestHeader("authorization", header);
        }
    }
});

//Feilds can be used to pass data betweeen controllers js
app.factory('SharedDataService', function () {
    var Data = {
        ErrorStatus: '',
        TierCode: '',
        reviewId: '',
        caseId: '',
        formId: '',
        reviewForm: {}
    };
    return Data;
});

app.factory('Excel', function ($window) {
    var uri = 'data:application/vnd.ms-excel;base64,',
        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
        base64 = function (s) { return $window.btoa(unescape(encodeURIComponent(s))); },
        format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) };
    return {
        tableToExcel: function (tableId, worksheetName) {
            var table = $(tableId),
                table = table.clone();
            var html = $('<div>').append(table).html();
            ctx = { worksheet: worksheetName, table: html },
                href = uri + base64(format(template, ctx));
            return href;
        }
    };
})

//app.config(['$translateProvider',
//      function ($translateProvider) {
//          $translateProvider.useSanitizeValueStrategy(null);
//          $translateProvider.useUrlLoader(ApiUrl + '/api/LocaleStringResource/Translate');
//      }]);

//app.run(['$rootScope','$translate', function ($rootScope, $translate) {
//    $rootScope.Init = function () {
//        var lang = localStorage.getItem("code") || 'en';
//        Setlanguage(lang, localStorage.getItem("lang") || "English");
//    };
//    function Setlanguage(code, lang) {
//        $(".lang").html(lang);
//        $("label,h3,h4,h5,p").attr("translate", "");
//        $translate.use(code);
//    }
//    $rootScope.setLanguage = function (code, lang) {
//        localStorage.setItem("code", code);
//        localStorage.setItem("lang", lang);
//        $rootScope.Init();
//    }

//    $rootScope.Init();
//}]);

app.directive('objectList', function ($compile, $injector) {
    return {
        template: 'OK',
        link: function (scope, element, attrs) {
            console.log("kj");
            var exist = $injector.has('myMessageDirective');
            //...
        }
    };
});

// Allow only US-Format Contact Number Digits as input in Textbox
app.directive('onlyNum', function () {
    return function (scope, element, attrs) {

        var keyCode = [8, 9, 37, 39, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 110, 187, 189, 67, 86];
        element.bind("keydown", function (event) {
            console.log($.inArray(event.which, keyCode));
            if ($.inArray(event.which, keyCode) == -1) {
                scope.$apply(function () {
                    scope.$eval(attrs.onlyNum);
                    event.preventDefault();
                });
                event.preventDefault();
            }
        });
    };
});

// Allow only Date Format as input in Textbox
app.directive('inputDate', function () {
    return function (scope, element, attrs) {
        var keyCode = [8, 9, 37, 39, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 110, 191];
        element.bind("keydown", function (e) {
            if ($.inArray(e.which, keyCode) == -1) {
                scope.$apply(function () {
                    scope.$eval(attrs.inputDate);
                    e.preventDefault();
                });
                e.preventDefault();
            }
        })
    }
});

//Ng-repeat on Final loop with html render
app.directive('onFinishRender', ['$timeout', '$parse', function ($timeout, $parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                $timeout(function () {
                    scope.$emit('ngRepeatFinished');
                    if (!!attr.onFinishRender) {
                        $parse(attr.onFinishRender)(scope);
                    }
                });
            }


            if (!!attr.onStartRender) {
                if (scope.$first === true) {
                    $timeout(function () {
                        scope.$emit('ngRepeatStarted');
                        if (!!attr.onStartRender) {
                            $parse(attr.onStartRender)(scope);
                        }
                    });
                }
            }
        }
    }
}]);

//Disable buttons until http request is processed/loaded
app.directive("disableonrequest", function ($http) {
    return function (scope, element, attrs) {
        scope.$watch(function () {
            return $http.pendingRequests.length > 0;
        }, function (request) {
            if (!request) {
                scope.pendingRequests = false;
                element.html("<span >" + attrs.notloading + "</span>");
            } else {
                scope.pendingRequests = true;
                element.html("<i class='fa fa-spinner fa-spin'></i>&nbsp;<span >Processing...</span>");
            }
        });
    }
});

//Disable buttons until http request is processed/loaded
app.directive("singleClick", ['$parse',
function ($parse) {
    return {
        restrict: 'A',
        scope: true,
        compile: function ($element, attr) {
            var fn = $parse(attr.singleClick);
            return function (scope, element) {
                scope.running = false;

                element.on("click", function (event) {
                    scope.$apply(function () {
                        if (!scope.running) {
                            var result = fn(scope, { $event: event });
                            if (!!result && result.finally !== undefined) {
                                scope.running = true;
                                element.addClass('state-waiting');
                                result.finally(function () {
                                    element.removeClass('state-waiting');
                                    scope.running = false;
                                });
                            }
                        }
                    });
                });
            };
        }
    };
}]);

//Disable Space in Form TextBox Value First Digit
app.directive('disallowFirstSpace', function () {
    return {
        restrict: 'A',
        link: function ($scope, $element) {
            $element.bind('keydown', function (e) {
                if ((e.which === 32 || e.which === 13) && e.target.selectionStart === 0) {
                    e.preventDefault();
                }
            });
            $element.on('paste', function (e) {
                if (e.target.selectionStart === 0 && !(/\S/.test(e.originalEvent.clipboardData.getData('text/plain')))) {
                    e.preventDefault();
                }
                //else {
                //    if (/(.*)\s+$/.test(e.originalEvent.clipboardData.getData('text/plain')))
                //    {
                //        alert('pace')
                //    }                    
                //}
            });
        }
    };
});

//Disable Space in Form TextBox
app.directive('disallowSpace', function () {
    return {
        restrict: 'A',
        link: function ($scope, $element) {
            $element.bind('keydown', function (e) {
                if (e.which === 32) {
                    e.preventDefault();
                }
            });
            $element.on('paste', function (e) {
                if (!(/\S/.test(e.originalEvent.clipboardData.getData('text/plain')))) {
                    e.preventDefault();
                }
            });
        }
    };
});

//Single and Dbclick handle
app.directive('sglclick', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            var fn = $parse(attr['sglclick']);
            var delay = 300, clicks = 0, timer = null;
            element.on('click', function (event) {
                clicks++;  //count clicks
                if (clicks === 1) {
                    timer = setTimeout(function () {
                        scope.$apply(function () {
                            fn(scope, { $event: event });
                        });
                        clicks = 0;             //after action performed, reset counter
                    }, delay);
                } else {
                    clearTimeout(timer);    //prevent single-click action
                    clicks = 0;             //after action performed, reset counter
                }
            });
        }
    };
}])