﻿var Schema = "";
var AuditFlag = false;
var dateUSFormat = 'MM/dd/yyyy';


function GetParameterValue(name, defaultVal) {

    var url = window.location;
    if (!url) url = location.href;
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(url);
    return results == null ? defaultVal : results[1];
}
function getComboText(control) {

    var input = $("#" + control).data("kendoComboBox");
    if (input != undefined) {
        return input.text();
    }
    return "";
}

function SetComboValue(control, Value) {
    if (Value != undefined || Value != null) {
        var input = $("#" + control).data("kendoComboBox");
        if (input != undefined) {
            var valueField = $("#" + control).data("kendoComboBox").options.dataValueField;
            if (Value == "") {
                $("#" + control).data("kendoComboBox").value("");
            }
            else {
                var data = $("#" + control).data("kendoComboBox").dataSource.data();
                if (data.length > 0) {
                    $.each(data, function (i, item) {
                        if (item["" + valueField] == getConvertedValue(item["" + valueField], Value)) {
                            $("#" + control).data("kendoComboBox").select(i);
                        }
                    });
                }
            }
        }
    } else {
        if ($("#" + control).length > 0)
            $("#" + control).data("kendoComboBox").select(-1)
    }
}

function SetMultiSelectorValue(control, Value) {

    Value = Value != null ? Value.split(',') : null;
    var input = $("#" + control).data("kendoMultiSelect");
    if (input != undefined) {
        $("#" + control).data("kendoMultiSelect").value(Value);
    }
}

function getConvertedValue(target, value) {
    var ret = value;
    if (typeof (target) == "number") {
        return parseInt(value);
    }
    else if (typeof (target) == "string") {
        return value.toString();
    }
    return ret;
}

function comboBoxClearInavlidEntry(e) {
    var widget = e;
    //var eleId = $(widget.element[0]).attr("id");
    // if (widget.value() && widget.select() === -1) {
    if (widget.select() === -1) {
        //SetComboValue($(widget.element[0]).attr("id"), null);
        widget.value("");
        //if (widget.dataSource._data.length > 0) {
        //    widget.search();
        //    widget.popup.close();
        //}
        return false;
    }
    return true;
}


function getComobBoxValue(control) {

    var input = $("#" + control).data("kendoComboBox");
    if (input != undefined) {
        var valueField = $("#" + control).data("kendoComboBox").options.dataValueField;
        var textField = $("#" + control).data("kendoComboBox").options.dataTextField;
        var data = $("#" + control).data("kendoComboBox").dataSource.data();
        var selected = $("#" + control).data("kendoComboBox").select();

        if (input._prev != undefined) {
            if (input._prev != "") {
                for (var i = 0; i < data.length; i++) {
                    if (data[i]["" + textField].toUpperCase() == input._prev.toUpperCase())
                        return data[i]["" + valueField];
                }
            }
        }
        return 0;
    }
    else {
        var input = $("#" + control).data("kendoDropDownList");
        if (input != undefined) {
            var valueField = $("#" + control).data("kendoDropDownList").options.dataValueField;
            var data = $("#" + control).data("kendoDropDownList").dataSource.data();
            var selected = $("#" + control).data("kendoDropDownList").select();
            if (data.length > 0 && selected >= 0) {
                if (data[selected]["" + valueField] != undefined) {
                    return data[selected]["" + valueField];
                }
            }
            return 0;
        }
    }

}

function ShowMessage(message, type) {
    $('body').addClass('toast-visible');
    var key = Math.random().toString(36).substr(10);
    $(".overlay").show();
    $("#AddNewId").hide();
    if (type == 'E') {
        $("#toastHead").text("Error");
    }
    else if (type == 'S') {
        $("#toastHead").text("Success");
    }
    else if (type == 'Ex') {
        $("#toastHead").text("Exist");
    }
    else if (type == 'W') {
        $("#toastHead").text("Warning");
        $("#App_AlertText").text("Invalid File format");
    }
    else if (type == 'A') {
        $("#toastHead").text("Alert");
    } else if (type == "I") {
        $("#toastHead").text("Info");
    }
    else if (type = "Saved") {
        $("#toastHead").text("Saved");
    }
    $("#toastData").text(message);
    $("#toast").show();
    setTimeout(function () {
        $('body').removeClass('toast-visible');
        $(".overlay").hide();
        $("#toast").hide();
    }, 15000);
}

function SetMessage(type) {
    $("#App_CloseAlert").hide();
    if (type == "Save") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Details Saved Successfully");
    }
    
else if (type == "NoData") {
        $("#App_AlertHead").text("No configuration set for selected Vehicle Type")
        $("#App_AlertText").text("Please configure parameters for selected vehicle type");
    }


    else if (type == "VehicleExist") {
        $("#App_AlertHead").text("Already configured within date range")
        $("#App_AlertText").text("Configuration already set for the vehicle within the Date range");
    }

    else if (type == "ActDoesntExistOrBalaned") {
        $("#App_AlertHead").text("Account number doesnt exist or Not balanced")
        $("#App_AlertText").text("Account number doesnt exist or the amount not balanced");
    }

    else if (type == "Insufficient") {
        $("#App_AlertHead").text("Insufficient account balance")
        $("#App_AlertText").text("Insufficient account balance");
    }


    else if (type == "InvalidAccount") {
        $("#App_AlertHead").text("Invalid account number")
        $("#App_AlertText").text("Invalid account number");
    }

    else if (type == "BalException") {
        $("#App_AlertHead").text("Exception while checking account balance")
        $("#App_AlertText").text("Exception occured while checking account balance");
    }

    else if (type == "TransException") {
        $("#App_AlertHead").text("Exception while doing transaction")
        $("#App_AlertText").text("Exception occured while doing transaction");
    }

    else if (type == "DataExist") {
        $("#App_AlertHead").text("Employee exists in database")
        $("#App_AlertText").text("Selected employee already exists in database");
    }
    else if (type == "Exist") {
        $("#App_AlertHead").text("Exists")
        $("#App_AlertText").text("Name already exists in the database");
    }

    else if (type == "Update") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Details Updated Successfully");
    }

    else if (type == "Approve") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Details Approved Successfully");
    }

   
    else if (type == "Delete") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Details Deleted Successfully");

    }
    
   
    else if (type == "Exist") {
        $("#App_AlertHead").text("Warning")
        $("#App_AlertText").text("This Record Already Exists");
    }
   
    else if (type == "CantDelete") {
        $("#App_AlertHead").text("Warning")
        $("#App_AlertText").text("Can't Delete this Record");
    }
    else if (type == "Error") {
        $("#App_AlertHead").text("Error")
        $("#App_AlertText").text("Error Occured While Processing Your Request");
    }
    

    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 100);
    setTimeout(function () {
        $("#App_Alert").fadeOut(400);
    }, 2000)
}
function CustomMessage(type, message) {
    $("#App_CloseAlert").hide();
    $("#App_AlertHead").text(type)
    $("#App_AlertText").text(message);
    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 200);
    setTimeout(function () {
        $("#App_Alert").fadeOut(400);
    }, 2000)
}

function CustomWindow(message, title) {
    var dfd = new jQuery.Deferred();
    var result = false;
    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: title,
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        },
        actions: {}
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();
    $('.popupMessage').html(message);
    $('#popupWindow .confirm_yes').val('OK');
    $('#popupWindow .confirm_no').hide();
    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });
    return dfd.promise();
}


function WarnMessage(message) {
    $("#App_CloseAlert").show();
    $("#App_AlertHead").text("Warning")
    $("#App_AlertText").text(message);
    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 100);
}

function RandamizeMessage(type, message) {
    $("#App_CloseAlert").show();
    $("#App_AlertHead").text(type)
    $("#App_AlertText").text(message);
    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 100);
}

function App_CloseAlert() {
    $("#App_Alert").fadeOut(200);
}

$(document).ready(function () {

    //Advanceed search script
    $(".search-toggle").click(function () {
        $(".dropdown-search").toggleClass("showdiv");
        $("div#search-overlay").toggleClass("showdiv");
        $("body").toggleClass("search-active");
        $(".dropdown-search").css({ "display": "" });
        return false;
    });
    $("#search-overlay").click(function () {
        $(".dropdown-search").toggleClass("showdiv");
        $("body").toggleClass("search-active");
        $("#search-overlay").toggleClass("showdiv");

    });

    $(document).on("keypress", ".text", function (event) {
        var regex = new RegExp("^[a-zA-Z ]+$");
        var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if (!regex.test(key) && event.which != 0 && event.which != 8) {
            event.preventDefault();
            return false;
        }
    });

    $(document).on("keypress", ".number", function (event) {
        var inputValue = event.which;
        if ((inputValue == 46 && inputValue > 31) && (inputValue < 48 || inputValue > 57)) {
            event.preventDefault();
        }

    });
});

// Advanceed search
function SearchBoxToggleClass() {
    $(".dropdown-search").toggleClass("showdiv");
    $("#search-overlay").toggleClass("showdiv");
    $("body").toggleClass("search-active");
}

function SearchBoxRemoveClass() {
    $(".dropdown-search").removeClass("showdiv");
    $("#search-overlay").removeClass("showdiv");
    $("body").removeClass("search-active");
}

function HideAudit() {
    $("#AuditWindow").removeClass('nav-view');
    $("body").removeClass('no-scroll');
    //setTimeout(function () {
    //    $("#AuditWindow").toggleClass('nav-view');
    //}, 300);
    $("#AuditOverlay").hide();

}

function GetAudit(target, id) {
    AuditFlag = true;
    $.ajax({
        contentType: "application/json",
        type: "Post",
        url: "/api/AuditTrial/Get?lookup=" + target + "&id=" + id,
        success: function (result) {
            $("#AuditWindow").toggleClass('nav-view');
            $("body").toggleClass('no-scroll');
            // $("#AuditWindow").animate({ transform: 'scale(1,1)' });
            $("#AuditOverlay").show();

            ShowAudit(result);
            AuditFlag = false;
        },
        error: function (data) {

        }
    });
}

function ShowAudit(data) {
    var html = ""; // "<tr><th>#</th><th>Action</th><th>Done By</th><th>Done At</th></tr>";
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            html += "<tr><td><div class='AuditMileStone'></div></td><td colspan='3'><b>" + data[i].Action + "</b> By <b>" + data[i].FullName + "</b> on <b>" + data[i].StrActionDate + "</b></td></tr>";
            if (data[i].ChangeList != null) {
                for (var k = 0; k < data[i].ChangeList.length; k++) {
                    html += "<tr><td>&nbsp;</td><td colspan='3' style='padding-left:20px;'><span style='color:blue'>" + data[i].ChangeList[k].Property + "</span> Updated <span style='color:green'>" + data[i].ChangeList[k].ChangeDetail + "</span></td></tr>";
                }
            }
        }
    }
    else
        html += "<tr><td colspan='4' style='text-align:center'>No History to show</tr>";
    $("#AuditData").html(html);

}

function ReadCookie(cname) {
    var re = new RegExp(cname + "=([^;]+)");
    var value = re.exec(document.cookie);
    return (value != null) ? unescape(value[1]) : null;
}

$('form').kendoValidator({
    errorTemplate: "<span  class='k-widget k-tooltip k-tooltip-validation' translate>#=message#</span>",
    rules: {
        required: function (input) {

            if (input.filter("[required]").length && $.trim(input.val()) == "") {
                input.val('');
                return false;
            }
            return true;
        },

    },
    messages: {
        required: "This field is required",
    }
});
function showWindow(message) {
    var dfd = new jQuery.Deferred();
    var result = false;
    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        },
        actions: {}
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();
    $('.popupMessage').html(message);
    $('#popupWindow .confirm_yes').val('OK');
    $('#popupWindow .confirm_no').hide();
    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });
    return dfd.promise();
};

function showConfirmationWindow(message) {

    var dfd = new jQuery.Deferred();
    var result = false;

    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "Confirmation",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();

    $('.popupMessage').html(message);

    $('#popupWindow .confirm_yes').val('OK');
    $('#popupWindow .confirm_no').val('Cancel');

    $('#popupWindow .confirm_no').click(function () {
        $('#popupWindow').data('kendoWindow').close();
    });

    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

function showConfirmationActiveWindow(message) {

    var dfd = new jQuery.Deferred();
    var result = false;

    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "Confirmation",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();

    $('.popupMessage').html(message);

    $('#popupWindow .confirm_yes').val('Yes');
    $('#popupWindow .confirm_no').val('No');

    $('#popupWindow .confirm_no').click(function () {
        $('#popupWindow').data('kendoWindow').close();
    });

    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

function showPromptWindow(message, defaultText) {

    var dfd = new jQuery.Deferred();
    var result = null;

    $("<div id='promptWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "Confirmation",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($('#promptTemplate').html()).center().open();

    $('#promptPopupMessage').html(message);
    $('#promptTxt').val(defaultText);

    $('#promptWindow .confirm_yes').val('OK');
    $('#promptWindow .confirm_no').val('Cancel');

    $('#promptWindow .confirm_no').click(function () {
        $('#promptWindow').data('kendoWindow').close();
    });

    $('#promptWindow .confirm_yes').click(function () {
        result = $('#promptTxt').val();
        $('#promptWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

function GetStatusTemplate(item) {
    var txt = item.IsActive ? "Active" : "Inactive";
    return "<span class='" + (item.IsActive ? 'Yes' : 'No') + "'>" + txt + "</span>";
};

function StatusCheck(item) {
    var str;
    str = item.Status;

    if (str == null || str == Constants.StatusType.Scheduled) {
        return "<span style='color:#0707cc;'>" + Constants.StatusType.Scheduled + "</span>";
    }
    if (str == Constants.StatusType.Assessed) {
        return "<span style='color:#f39c12'> Assessed </span>";
    }
    if (str == Constants.StatusType.RFSReviewed) {
        return "<span style='color:#ec09ec'>  Reviewed </span>";
    }
    if (str == Constants.StatusType.RFSReSubmitted) {
        return "<span style='color:#ec09ec'>  ReSubmitted </span>";
    }
    if (str == Constants.StatusType.Complete) {
        return "<span style='color:green'> Completed </span>";
    }
    if (str == Constants.StatusType.AreaManagerRejected) {
        return "<span style='color:orange'> Rejected </span>";
    }
    if (str == Constants.StatusType.Escalated) {
        return "<span style='color:red'>" + Constants.StatusType.Escalated + "</span>";
    }
    if (str == Constants.StatusType.RejectedEscalation) {
        return "<span style='color:orange'>" + Constants.StatusType.RejectedEscalation + "</span>";
    }
    if (str == Constants.StatusType.Rescheduled) {
        return "<span style='color:#ec09ec'>" + Constants.StatusType.Rescheduled + "</span>";
    }
    if (str == Constants.StatusType.Closed) {
        return "<span style='color:orange'>" + Constants.StatusType.Closed + "</span>";
    }
    if (str == Constants.StatusType.Draft) {
        return "<span style='color:#ec09ec'>" + Constants.StatusType.Draft + "</span>";
    }
}
function result(item) {
    var str;
    str = item.Result;
    if (str.toLowerCase().trim() == 'pass') {
        return "<span class='resultPass'>" + 'Pass' + "</span>"
    }
    if (str.toLowerCase().trim() == 'fail') {
        return "<span class='resultFail'>" + 'Fail' + "</span>"
    }
}
function findIndex(arraytosearch, key, valuetosearch) {
    for (var i = 0; i < arraytosearch.length; i++) {
        if (arraytosearch[i][key] == valuetosearch) {
            return i;
        }
    }
    return null;
}

function hideloader() {
    $('#LoadingImg').hide();
    // $(".content").show();
}
function showloader() {
    $('#LoadingImg').show();

}
function OnKendoDataBound() {
    var grid = this;
    this.tbody.find("tr[role='row']").each(function () {
        var model = grid.dataItem(this);
        //if (model.Isexists != 0) {
        //    $(this).css({ "background-color": "silver" });
        //    $(this).find(".k-grid-editt").prop('disabled', true);
        //    $(this).find(".k-grid-deletee").prop('disabled', true);
        //}
        if (model.IsActive) {
            $(this).find(".k-grid-activate").remove();
        } else {
            $(this).find(".k-grid-deactivate").remove();
        }
    });

    if (this.dataSource.view().length == 0) {
        var currentPage = this.dataSource.page();
        if (currentPage > 1) {
            this.dataSource.page(currentPage - 1);
        }
    }
}
function GetInactveTemplate(item) {
    if (item.IsActive) {
        return item.Name;
    }
    return "<span class='inactive'>" + item.Name + " (Inactive)<span>";
}
function getParameterByName(name) {
    var url = window.location;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function OnError(response) {
    window.location.href = "/HOME/ERROR?ExceptionType=" + response.data.ExceptionType;
}

//To append the parameter(s) to the URL
function URL_add_parameter(url, param, value) {
    var hash = {};
    var parser = document.createElement('a');

    parser.href = url;

    var parameters = parser.search.split(/\?|&/);

    for (var i = 0; i < parameters.length; i++) {
        if (!parameters[i])
            continue;

        var ary = parameters[i].split('=');
        hash[ary[0]] = ary[1];
    }

    hash[param] = value;

    var list = [];
    Object.keys(hash).forEach(function (key) {
        list.push(key + '=' + hash[key]);
    });

    parser.search = '?' + list.join('&');
    return parser.href;
}

// for Pie High chart
// InnerSize = 0
// Depth = 0

// for Donut High chart
// InnerSize = 100
// Depth = 45
function getPieDonutHighChart(controlId, chartType, dataToDisplay, InnerSize, Depth, onClick) {
    Highcharts.chart(controlId, {
        chart: {
            type: chartType,
            options3d: {
                enabled: true,
                alpha: 45,
                beta: 0,
            }
        },
        title: {
            text: ''
        },
        tooltip: {
            //pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                innerSize: InnerSize,
                depth: Depth,
                allowPointSelect: true,
                cursor: 'pointer',
                depth: 35,
                dataLabels: {
                    enabled: true,
                    format: '{point.name}'
                }
            }
        },
        credits: {
            enabled: false
        },
        exporting: { enabled: false },
        series: [{
            type: chartType,
            data: dataToDisplay,
            showInLegend: false,
            name: ' ',
            cursor: 'pointer',
            point: {
                events: {
                    click: function (event) {
                        window.location = onClick
                    }
                }
            }
        }]
    });
}

function getColumnHighChart(controlId, chartType, xAxisData, seriesData) {
    var chart = new Highcharts.Chart({
        chart: {
            renderTo: controlId,
            type: chartType,
            options3d: {
                enabled: true,
                alpha: 15,
                beta: 15,
                depth: 50,
                viewDistance: 25
            }
        },
        title: {
            text: ''
        },
        xAxis: {
            categories: xAxisData
        },
        subtitle: {
            text: ''
        },
        plotOptions: {
            column: {
                depth: 25
            }
        },
        credits: {
            enabled: false
        },
        exporting: { enabled: false },
        plotOptions: {
            series: {
                cursor: 'pointer',
                events: {
                    click: function (event) {
                        window.location = '/QualityControlCaseReview/AllReview'
                    }
                }
            }
        },
        series:
            [{
                data: seriesData,
                showInLegend: false,
                name: ' '
            }]
    });
    return chart;
}
function getLineChart(controlId, chartType, xAxisData, seriesData, chartTitle, seriesName, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #%",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}%"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: [{
            data: seriesData,
            //name: 'CalFresh',
            showInLegend: false,
        }],
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        seriesColors: _colorList,
        tooltip: {
            visible: true,
            position: "top",
            template: "#= category # : #= value #%"
        }
    });
}
function getLineChartWithoutPercentage(controlId, chartType, xAxisData, seriesData, chartTitle, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: [{
            data: seriesData,
            //name: 'CalFresh',
            showInLegend: false,
        }],
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= category # : #= value #"
        },
        seriesColors: _colorList
    });
}
function getLineChartForMultipleYAxis(controlId, chartType, xAxisData, seriesData, chartTitle, seriesName, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #%",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}%"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: seriesData,
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= series.name #: #= value #%"
        },
        seriesColors: _colorList
    });
}
function getLineChartForMultipleYAxisWithoutPercentage(controlId, chartType, xAxisData, seriesData, chartTitle, seriesName, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: seriesData,
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= series.name #: #= value #"
        },
        seriesColors: _colorList
    });
}
function getColumnHighChartForReports(controlId, chartType, xAxisData, seriesData, chartTitle, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];    
    $("#" + controlId).kendoChart({
        legend: {
            visible: false
        },
        title: {
            text: chartTitle
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                format: "#= category #: #= value #",
                background: "transparent"
            }
        },
        series: [{
            data: seriesData
        }],
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= category #: #= value #"
        },
        seriesColors: _colorList
    });
}

// Disable Space in Form TextBox First Digit
function disableFirstSpace(e) {
    if (e.which === 32 && e.target.selectionStart === 0) {
        e.preventDefault();
    }
}